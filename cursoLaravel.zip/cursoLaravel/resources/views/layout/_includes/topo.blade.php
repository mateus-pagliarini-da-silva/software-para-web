<html>
<head>
    <title>@yield('titulo')</title>
</head>
<body>